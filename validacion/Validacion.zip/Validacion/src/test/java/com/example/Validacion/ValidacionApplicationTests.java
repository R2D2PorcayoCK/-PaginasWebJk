package com.example.Validacion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ValidacionApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.example.ListKevin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ListKevinApplication {

	public static void main(String[] args) {
		SpringApplication.run(ListKevinApplication.class, args);
	}

}

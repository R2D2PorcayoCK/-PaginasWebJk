package com.example.ListKevin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ListKevinApplicationTests {

	@Test
	void contextLoads() {
	}

}
